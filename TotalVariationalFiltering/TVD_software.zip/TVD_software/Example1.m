%% Example: TV Denoising using MM
% TV denoising using an algorithm derived using majorization-minimization (MM)
% and solvers for sparse banded systems.
% See accompanying notes.
%
% Ivan Selesnick, selesi@poly.edu, 2011

%% Start

clear
close all
printme = @(filename) print('-dpdf', sprintf('Example1_%s', filename));

%% Create data

N = 256;                        % N : signal length
s = MakeSignal('Blocks',N);     % s : noise-free signal
s = s(:);                       % convert to column 

randn('state',0);               % set seed to reproduce noise signal
noise = 0.5*randn(N,1);
y = s + noise;                  % y : noisy signal

figure(1)
clf
subplot(2,1,1)
plot(s)
ax = [0 N -3 6];
axis(ax)
box off
title('Clean signal')

subplot(2,1,2)
plot(y)
axis(ax)
box off
title('Noisy signal')
xlabel(' ')

printme('fig1')

%% TV Denoising
% Run TV denoising algorithm (MM algorithm)

lam = 2.0;                          % lam: regularization parameter
Nit = 20;                           % Nit: number of iterations
[x, cost] = TVD_mm(y, lam, Nit);    % Run MM TV denoising algorithm

figure(2)
clf
subplot(2,1,1)
plot(1:Nit, cost, '.-')
box off
title('Cost function history')
xlabel('Iteration')

subplot(2,1,2)
plot(x)
axis(ax)
box off
title('TV denoising')
xlabel(' ')

printme('fig2')

%% Compare two algorithms
% Compare convergence behavour of two algorithms:
% Iterative clipping and MM

lam = 2.0;
Nit = 100;
[x, cost] = TVD_mm(y, lam, Nit);
[x2,cost2] = TVD_ic(y,lam,Nit);

figure(1)
clf
plot(1:Nit, cost2,'--', 1:Nit, cost,'-')
legend('Iterative Clipping Algorithm','Majorize-Mininize Algorithm')
legend boxoff
xlabel('Iteration')
title('Cost function history')
box off
ylim([120 150])

printme('fig3')


%% Optimality condition
% Illustrate optimality condition: abs(cumsum(x-y)) <= lambda/2

z = cumsum(x-y);

figure(1)
clf
subplot(2,1,1)
plot(z)
xlim([0 N])
box off
line([0 N],[1 1]*lam/2, 'linestyle', '--')
line([0 N],-[1 1]*lam/2, 'linestyle', '--')
ylim([-1.5 1.5]*lam/2)
xlabel(' ')
ylabel('s(n)')
title('s(n) = cumsum(y-x)');
set(gca,'fontname','symbol')
set(gca, 'ytick', [-1 0 1]*lam/2, 'yticklabel', {'-l/2', '0', 'l/2'});

printme('optim')


%% Optimality scatter plot
% Illustrate optimality conidition using scatter plot diagram

z = cumsum(x-y);

figure(1)
clf
plot(z(1:end-1), diff(x),'.')
m = max(abs(diff(x)));
xlabel('cumsum(y-x)')
ylabel('diff(x)')
ylim([-1.2 1.2]*m)
xlim([-1.5 1.5]*lam/2)
set(gca,'fontname','symbol')
set(gca, 'xtick', [-1 0 1]*lam/2, 'xticklabel', {'-l/2', '0', 'l/2'});
box off

printme('optim_2')


