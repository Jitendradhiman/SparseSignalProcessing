function figlab(str)
% figlab(str)
% text(0.05, 0.95, str, 'units', 'normalized', 'background', 'white');

text(0.05, 0.95, str, 'units', 'normalized', 'background', 'white');


