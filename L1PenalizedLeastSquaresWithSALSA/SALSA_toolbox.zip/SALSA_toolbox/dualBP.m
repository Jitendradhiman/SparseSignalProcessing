function [x1, x2, c1, c2, cost] = dualBP(x, A1, A1H, A2, A2H, theta, mu, Nit, plot_flag)

% [x1, x2, c1, c2] = dualBP(x, A1, A1H, A2, A2H, theta, mu, Nit);
%
% DUAL BASIS PURSUIT
% Signal decomposition using two transforms (Parseval frames)
% Minimize with respect to (c1, c2):
% theta ||c1||_1 + (1-theta) ||c2||_2  subject to x = A1 c1 + A2 c2
%
% Requirements:
%    A1 A1H = I
%    A2 A2H = I
%    0 < theta < 1
%
% INPUT
%   x                : input signal signal
%   A1H, A1, A2, A2H : functions handles for Parseval frames and inverses
%   theta            : balance parameter
%   mu               : Augmented Lagrangian parameter
%   Nit              : number of iterations
%
% OUTPUT
%   x1, x2 : components
%   c1, c2 : coefficients of components
%
% Use [x1, x2, c1, c2, cost] = dualBP(...) to return cost function history.

% Ivan Selesnick
% Polytechnic Institute of New York University
% May 2010
% Revised August 2011

% Reference:
% I. W. Selesnick. Sparse signal representations using the tunable Q-factor wavelet transform.
% Proc. SPIE 8138 (Wavelets and Sparsity XIV), August 2011. doi:10.1117/12.894280.

% Reference
% M. V. Afonso, J. M. Bioucas-Dias, and M. A. T. Figueiredo.
% Fast image recovery using variable splitting and constrained optimization.
% IEEE Trans. Image Process., 19(9):2345–2356, September 2010.

p1 = 1;
p2 = 1;
%   p1, p2           : Parseval constants (A1*A1H = p1*I, A2*A2H = p2*I)

mu1 = mu;
mu2 = mu;

lam1 = theta;
lam2 = 1 - theta;

% By default do not compute cost function (to reduce computation)
if nargout > 4
    COST = true;
    cost = zeros(1,Nit);     % cost function
else
    COST = false;
    cost = [];
end

GOPLOTS = false;
% if nargin == 11
%     if strcmp(plot_flag,'plots')
%         GOPLOTS = true;
%     end
% end

% Initialize:

c1 = A1H(x);
c2 = A2H(x);

d1 = A1H(zeros(size(x)));
d2 = A2H(zeros(size(x)));

T1 = lam1/mu1;
T2 = lam2/mu2;

N = length(x);
A = 1.1*max(abs(x));

C1 = (1/mu1)/(p1/mu1 + p2/mu2);
C2 = (1/mu2)/(p1/mu1 + p2/mu2);

for k = 1:Nit
    % fprintf('Iteration %d\n', k)
    
    u1 = soft(c1 + d1, T1) - d1;
    u2 = soft(c2 + d2, T2) - d2;
    
    c = x - A1(u1) - A2(u2);
    % c = 0.5 * c;
    
    d1 = C1*A1H(c);
    d2 = C2*A2H(c);
    
    c1 = d1 + u1;
    c2 = d2 + u2;
    
    if COST
        cost(k) = lam1*sum(abs(c1(:))) + lam2*sum(abs(c2(:)));
    end
    
    if GOPLOTS
        x1 = A1(c1);
        x2 = A2(c2);
        res = x - x1 - x2;
        
        figure(gcf)
        clf
        subplot(3,1,1)
        plot(real(x1))
        xlim([0 N])
        ylim([-A A])
        title({sprintf('ITERATION %d',k),'COMPONENT 1'})
        box off
        subplot(3,1,2)
        plot(real(x2))
        xlim([0 N])
        ylim([-A A])
        box off
        title('COMPONENT 2')
        subplot(3,1,3)
        plot(real(res))
        xlim([0 N])
        ylim([-A A])
        title('RESIDUAL')
        box off
        drawnow
    end
    
end

x1 = A1(c1);
x2 = A2(c2);

